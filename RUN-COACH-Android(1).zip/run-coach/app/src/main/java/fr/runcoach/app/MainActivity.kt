package fr.runcoach.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF263D2D)
private val Ochre = Color(0xFFC18A3A)
private val Terracotta = Color(0xFFB85C38)
private val Cream = Color(0xFFF1E6D2)
private val Rust = Color(0xFF8C321F)
private val Olive = Color(0xFF6A673B)
private val Chocolate = Color(0xFF533A2A)
private val Burgundy = Color(0xFF5C211F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("run_coach", MODE_PRIVATE)
        setContent {
            var tab by remember { mutableStateOf("Accueil") }
            var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
            var challengeDone by remember { mutableStateOf(prefs.getBoolean("challenge", false)) }
            var runs by remember { mutableIntStateOf(prefs.getInt("runs", 1)) }
            MaterialTheme(colorScheme = lightColorScheme(primary = Forest, secondary = Ochre, background = Cream, surface = Color.White)) {
                Scaffold(containerColor = Cream, bottomBar = {
                    NavigationBar(containerColor = Forest) {
                        listOf("Accueil", "Séances", "Renfo", "Bilan").forEach { item ->
                            NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = { Text(when(item) { "Accueil" -> "⌂"; "Séances" -> "◷"; "Renfo" -> "✦"; else -> "↗" }, fontSize = 20.sp) }, label = { Text(item, color = Cream) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Ochre, indicatorColor = Color(0xFF405642), unselectedIconColor = Cream))
                        }
                    }
                }) { padding ->
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        item { Text("RUN COACH", color = Forest, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold); Text("Ton coach running au quotidien", color = Chocolate) }
                        when (tab) {
                            "Accueil" -> {
                                item { Panel("TA PROCHAINE SÉANCE", "Endurance fondamentale · 45 min", "Allure confortable : tu dois pouvoir parler sans être essoufflé.", Ochre) }
                                item { Panel("RÉCUPÉRATION", "À l'écoute de tes sensations", "Adapte la séance à ta fatigue et à toute douleur. Le repos fait partie de la progression.", Olive) }
                                item { Panel("DÉFI DU JOUR", if (challengeDone) "Défi validé !" else "Équilibre sur une jambe", if (challengeDone) "Bravo, défi accompli." else "2 × 30 secondes de chaque côté, près d'un appui si besoin.", Terracotta) }
                                item { Button(onClick = { challengeDone = !challengeDone; prefs.edit().putBoolean("challenge", challengeDone).apply() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Forest)) { Text(if (challengeDone) "Annuler le défi" else "Valider mon défi") } }
                                item { Panel("CETTE SEMAINE", "$completed séance(s) validée(s)", "Objectif indicatif : deux sorties, placées librement dans ton agenda.", Burgundy) }
                            }
                            "Séances" -> {
                                item { Panel("SÉANCE 1 · ENDURANCE", "45 minutes faciles", "10 min très faciles, 30 min en aisance respiratoire, 5 min de retour au calme.", Ochre) }
                                item { Panel("SÉANCE 2 · VITESSE", "Fractionné doux · 40 min", "10 min échauffement, 6 × (1 min dynamique + 1 min 30 lente), puis retour au calme.", Terracotta) }
                                item { Text("Choisis toi-même tes jours. Espace si possible les sorties d'environ 48 h et ne rattrape pas une séance manquée en doublant.", color = Chocolate) }
                                item { Button(onClick = { completed++; prefs.edit().putInt("completed", completed).apply() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Forest)) { Text("Marquer une séance comme terminée") } }
                            }
                            "Renfo" -> {
                                item { Panel("RENFORCEMENT SANS MATÉRIEL", "Routine express · 10 min", "2 tours tranquilles : 10 squats, 12 ponts fessiers, 10 élévations latérales par côté, 8 bird-dogs par côté, 15 montées sur pointes.", Olive) }
                                item { Panel("VERSION MINI", "2 à 3 minutes", "Quelques squats, montées sur pointes ou exercices d'équilibre répartis dans la journée.", Ochre) }
                                item { Text("Choisis la version adaptée à ta récupération. Pas d'exercice qui déclenche une douleur.", color = Chocolate) }
                            }
                            else -> {
                                item { Panel("TON SUIVI", "$runs sortie de référence", "Ta première donnée de référence : 6,05 km en 46 min 56 s · allure moyenne 7 min 46 s/km. FC moyenne 164 bpm.", Burgundy) }
                                item { Panel("PROCHAINE ÉTAPE", "Importer tes activités Garmin", "L'import des fichiers FIT et l'analyse détaillée seront ajoutés dans une prochaine version.", Terracotta) }
                                item { Button(onClick = { runs++; prefs.edit().putInt("runs", runs).apply() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Forest)) { Text("Ajouter une sortie (compteur test)") } }
                            }
                        }
                        item { Text("RUN COACH · Version de départ 0.1.0", color = Chocolate.copy(alpha = .7f), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Panel(title: String, headline: String, detail: String, accent: Color) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(Modifier.width(7.dp).fillMaxHeight().background(accent))
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(title, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(headline, color = Forest, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(detail, color = Chocolate, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
    }
}
