# RUN COACH — Android

Application Android native en français, version de départ 0.1.0.

## Compilation automatique
Le workflow GitHub Actions `.github/workflows/build-apk.yml` compile l'application et publie `app-debug.apk` comme artefact téléchargeable.

Dans GitHub : onglet **Actions** → **Construire RUN COACH APK** → **Run workflow**. Attendre la fin du travail puis télécharger l'artefact `RUN-COACH-APK`.

## Contenu actuel
- Tableau de bord
- Séances de course proposées sur une base flexible
- Renforcement au poids du corps et défi quotidien
- Premiers repères de suivi

Les données du défi et des compteurs sont enregistrées localement sur le téléphone. L'import Garmin FIT, l'analyse avancée, le calendrier éditable et l'adaptation complète du coaching restent à développer.
